//
// Copyright © 2017 MIA s.r.l.
// All rights reserved.
//

#import <Foundation/Foundation.h>
#import <mkApp/MKConstants.h>

NS_ASSUME_NONNULL_BEGIN

/// @brief All the relation type supported by @e MIAQuery.
typedef NS_ENUM(NSInteger, MIAQueryRelationType) {
    MIAQueryRelationLessThan = -3,
    MIAQueryRelationLessThanOrEqual = -2,
    MIAQueryRelationNotEqual = -1,
    MIAQueryRelationEqual = 0,
    MIAQueryRelationGreaterThanOrEqual = 1,
    MIAQueryRelationGreaterThan = 2
};

typedef NS_OPTIONS(NSUInteger, MIAQueryRegexOptions) {
    MIAQueryRegexOptionCaseInsensitive = 1 << 0,
    MIAQueryRegexOptionMultiline = 1 << 1,
    MIAQueryRegexOptionDotall = 1 << 2,
};

@class MKCollection;

/**
 *  @brief This class is used to create a request for data to the server.
 */
@interface MIAQuery : NSObject <NSCopying>

/// @brief The name of the remote collection to query.
@property (nonatomic, copy) NSString *collectionName;
/// @brief The limit of the query. The maximum value is 500, and the minimum is 1.
@property (nonatomic) NSInteger limit;
/// @brief The number of element to skip. The minimum value is 0.
@property (nonatomic) NSInteger skip;

#pragma mark - Intialization

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype) new NS_UNAVAILABLE;

+ (instancetype)queryWithCollectionName:(NSString *)collectionName;
- (instancetype)initWithCollectionName:(NSString *)collectionName;

#pragma mark Filters

/**
 *  @brief Add a new Filtert for @p key to the query.
 *  @param key The key on witch data will be filtered.
 *  @param type The type of the filter to be applied to the @p key.
 *  @param object The object of the filter.
 */
- (void)addFilterForKey:(NSString *)key relatedBy:(MIAQueryRelationType)type toObject:(id)object;
/**
 *  @brief Add a filter to the query that requires a particular key's object
 to be contained in the provided array.
 *  @param key The key on witch data will be filtered.
 *  @param array The array of possible values for the key's object.
 */
- (void)addFilterForKey:(NSString *)key containedInArray:(NSArray *)array;
/**
 *  @brief Add a filter to the query that requires a particular key's object
 not be contained in the provided array.
 *  @param key The key on witch data will be filtered.
 *  @param array The array of possible values the key's object should not be.
 */
- (void)addFilterForKey:(NSString *)key notContainedInArray:(NSArray *)array;
/**
 *  @brief Add a filter to the query that requires a particular key's array
 *      contains every element of the provided array.
 *  @param key The key on witch data will be filtered.
 *  @param array The array of values to search for.
 */
- (void)addFilterForKey:(NSString *)key containsAllObjectsInArray:(NSArray *)array;

/**
 *  @brief Exlude the specified @p keys from the result entities.
 *  @discussion This method is mutally exclusive with @e includeKeysInResults:
 */
- (void)excludeKeysFromResults:(NSArray<NSString *> *)keys;

/**
 *  @brief Include only the specified @p keys in the result entities.
 *  @discussion This method is mutally exclusive with @e excludeKeysFromResults:
 */
- (void)includeKeysInResults:(NSArray<NSString *> *)keys;

#pragma mark Regex

/**
 *  @brief Add a regular expression filter for finding string values that match
 *      the provided regular expression.
 *  @warning This may be slow for large datasets.
 *  @param key The key where the string to match is stored in.
 *  @param regex The regular expression pattern to match.
 */
- (void)addFilterForKey:(NSString *)key whereMatchesRegex:(NSString *)regex;

/**
 *  @brief Add a regular expression filter for finding string values that match
 *      the provided regular expression.
 *  @warning This may be slow for large datasets.
 *  @param key The key where the string to match is stored in.
 *  @param regex The regular expression pattern to match.
 *  @param options The regex option to apply.
 */
- (void)addFilterForKey:(NSString *)key whereMatchesRegex:(NSString *)regex options:(MIAQueryRegexOptions)options;
/**
 *  @brief Add a filter for finding string values that start with a provided prefix.
 *  @warning This will be slow for large datasets.
 *  @param key The key where the string to match is stored in.
 *  @param prefix The substring that the value must start with.
 */
- (void)addFilterForKey:(NSString *)key whereHasPrefix:(NSString *)prefix;
/**
 *  @brief Add a filter for finding string values that end with a provided suffix.
 *  @warning This will be slow for large datasets.
 *  @param key The key where the string to match is stored in.
 *  @param suffix The substring that the value must end with.
 */
- (void)addFilterForKey:(NSString *)key whereHasSuffix:(NSString *)suffix;

#pragma mark Sorting

/**
 *  @brief Sort the results for @p key.
 *  @param key The key for which the results are sorted.
 *  @param ascending If @e YES the results are sorted in @b ascending order,
 in @b descending order otherwise.
 */
- (void)sortKey:(NSString *)key ascending:(BOOL)ascending;
/**
 *  @brief Additionally sort the results for @p key.
 *      The previous keys took precedence over this.
 *  @param key The key for which the results are sorted.
 *  @param ascending If @e YES the results are sorted in @b ascending order,
 in @b descending order otherwise.
 */
- (void)addSortKey:(NSString *)key ascending:(BOOL)ascending;
/**
 *  @brief Sort the results using a given array of @e NSSortDescriptor.
 *  @warning If a sort descriptor has custom selector or comparator, they aren't going to be used.
 *  @param sortDescriptors An array of @e NSSortDescriptor objects to use to sort the results of the query.
 */
- (void)orderBySortDescriptors:(NSArray<NSSortDescriptor *> *)sortDescriptors;

#pragma mark Composition

/// @brief Return a new @e MIAQuery object that is the logical or between all the @e MIAQuery cotnained in queries.
+ (instancetype)orQueryWithSubqueries:(NSArray<MIAQuery *> *)queries;
/// @brief Return a new @e MIAQuery object that is the logical and between all the @e MIAQuery cotnained in queries.
+ (instancetype)andQueryWithSubqueries:(NSArray<MIAQuery *> *)queries;

#pragma mark Get Object by ID

/**
 *  @brief This method mutates the query.
 *      It will reset limit to @e 1, skip to @e 0 and remove all conditions, leaving only @p objectID.
 *  @param objectID The @p collectionId of a @p MKCollection instance.
 *  @param completionHandler The block called at the end of the execution of the network request.
 */
- (void)getObjectWithID:(NSString *)objectID withCompletionBlock:(MIASingleResultBlock)completionBlock;

#pragma mark Find Objects
/**
 *  @brief Finds objects asynchronously and calls the given block with the results.
 *  @param completionHandler The block called at the end of the execution of the network request.
 */
- (void)findObjectsWithCompletionBlock:(MIAResultsBlock)completionBlock;

/**
 *  @brief This method mutates the query. It will reset limit to @e 1 and skip to @e 0.
 *  @param completionHandler The block called at the end of the execution of the network request.
 */
- (void)findFirstObjectWithCompletionBlock:(MIASingleResultBlock)completionBlock;

#pragma mark Count Object

/**
 *  @brief Counts objects *asynchronously* and calls the given block with the counts.
 *  @param completionHandler The block called at the end of the execution of the network request.
 */
- (void)countObjectsWithCompletionBlock:(MIACountResultBlock)completionBlock;

#pragma mark Canceling

/// @brief Call this method for cancel the query request. The completion handler will not be called.
- (void)cancel;

@end

@interface MIAQuery (SynchronousCalls)

#pragma mark Get Object by ID

- (nullable MKCollection *)getObjectWithID:(NSString *)objectID;
- (nullable MKCollection *)getObjectWithID:(NSString *)objectID error:(NSError **)error;

#pragma mark Find Objects

- (nullable NSArray<MKCollection *> *)findObjects;
- (nullable NSArray<MKCollection *> *)findObjectsWithError:(NSError **)error;

- (nullable MKCollection *)findFirstObject;
- (nullable MKCollection *)findFirstObjectWithError:(NSError **)error;

#pragma mark Count Object

- (nullable NSNumber *)countObjects;
- (nullable NSNumber *)countObjectsWithError:(NSError **)error;

@end

NS_ASSUME_NONNULL_END

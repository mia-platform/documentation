//
//  MKConstants.h
//  mkApp
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#pragma mark - SDK Version
#define MIACOREKIT_VERSION @"1.2.0"

typedef NS_ENUM(NSInteger, MKAPPCachePolicy) {
    MKAPPIgnoreCache = NSURLRequestReloadIgnoringLocalCacheData,
    MKAPPUseCacheElseLoad = NSURLRequestReturnCacheDataElseLoad,
    MKAPPUseCacheDontLoad = NSURLRequestReturnCacheDataDontLoad
};

typedef NS_ENUM(NSInteger, MKAPPError) {
    MKAPPErrorNone = 0,
    MKAPPErrorInvalidParams = 100,
    MKAPPErrorOperationFailed = 101,
    MKAPPErrorOperationNotAllowed = 102,
    MKAPPErrorDuplicateKey = 103,
    MKAPPErrorObjectIsNotACollection = 104,
    MKAPPErrorInvalidValueType = 105,
    MKAPPErrorNullFileName,
    MKAPPErrorNullFileSize,
    MKAPPErrorNullFileUrl,
    MKAPPErrorMalformedEmail,
    MKAPPErrorConnectionFailed = 200,
    MKAPPErrorInvalidResponse,
    MKAPPErrorUnknownStatus,
    MKAPPErrorUnknownFileName,
    MKAPPErrorAdvGenericError = 300,
    MKAPPErrorAdvNoSpotAvailable,
    MKAPPErrorAdvNotConfigured,
    MKAPPErrorInvalidURL = 106
};

/**
 *  @brief @e MIALogLevel enum specifies different levels of logging that could be used
 *      to limit or display more messages in logs.
 */
typedef NS_ENUM(NSInteger, MIALogLevel) {
    /// @brief Log level that disables all logging.
    MIALogLevelNone = 0,
    /// @brief Log level that if set is going to output error messages to the log.
    MIALogLevelError = 1,
    /// @brief Log level that if set is going to output all kind of debug messages to the log.
    MIALogLevelVerbose = 2,
};

#pragma mark - Blocks

/// @brief Block used for returning an array of objects and an error.
typedef void (^MIAResultsBlock)(NSArray *_Nullable objects, NSError *_Nullable error);
/// @brief Block used for returning an single object and an error.
typedef void (^MIASingleResultBlock)(id _Nullable object, NSError *_Nullable error);
/// @brief Block used for returning an number and an error.
typedef void (^MIACountResultBlock)(NSNumber *_Nullable count, NSError *_Nullable error);
/// @brief Block used for returning an success flag and an error.
typedef void (^MIASuccessResultBlock)(BOOL success, NSError *_Nullable error);

#pragma mark - Notifications

/// @brief Notification sent before sending a network request.
FOUNDATION_EXPORT NSString *const MIAWillSendURLRequestNotification;
/// @brief Notification sent after receiving a network request.
FOUNDATION_EXPORT NSString *const MIADidReceiveURLRequestNotification;
/// @brief The key inside the userInfo dictionary of the notification containing the URLRequest.
FOUNDATION_EXPORT NSString *const MIANotificationURLRequestKey;
/// @brief The key inside the userInfo dictionary of the notification containing the URLResponse if available.
FOUNDATION_EXPORT NSString *const MIANotificationURLResponseKey;

NS_ASSUME_NONNULL_END

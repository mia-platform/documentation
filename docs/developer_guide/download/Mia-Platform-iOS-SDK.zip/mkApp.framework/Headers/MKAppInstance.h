//
//  MKManager.h
//  mkApp
//
//  Created by FSS
//  Copyright © 2017 MIA s.r.l. All rights reserved.
//

#import <mkApp/MKConstants.h>
#import <mkApp/MIANetwork.h>

@class MKUser, MKCollection;

extern NSString *const kMIAUserLoggedInNotification;

typedef enum { MKProduction, MKDevelop, MKTest } MKEndPointType __attribute__((deprecated));

typedef NS_ENUM(NSInteger, MKNotificationStytle) {
    MKNotificationStyleDefault,
    MKNotificationStyleError,
    MKNotificationStyleSuccess,
    MKNotificationStyleInfo,
    MKNotificationStyleWarning,
    MKNotificationStyleMia
};

typedef void (^MKNotificationTouchHandler)(void);

/**
 The manager is used to configure mkApp parameters
 */
@interface MKAppInstance : NSObject

@property (strong, nonatomic) NSString *projectAPIname;

/**
 *  @brief Set JSON Data format in seconds. The default is in millisecondi
 *  @description 'YES' to enable json date format in seconds
 */
@property (assign) BOOL jsonDateFormatInSeconds;

/**
 *  @brief Force collection name to lowercase in REST JSON request and query. The default is 'NO'
 *  @description 'YES' to force lowercase collection name
 */
@property (assign) BOOL jsonCollectionNameLowerCaseOnly;

/**
 *  @brief Force to never show "Welcome Back" notification at user login
 *  @description 'YES' prevent welcome messagge to be displayed
 */
@property (assign) BOOL neverNotifyLogin;

/** @name sharedInstance */

/**
 The singleton instance
 @return Returns the singleton, the first call create it
 @exception nil
 */

+ (instancetype)sharedInstance;

/** @name getLoggedUser */

/**
 The logged user
 @return Returns the logged User or nil
 @exception nil
 */

- (MKUser *)getLoggedUser;

/** @name refreshLoggedUser: */

/**
 *  If logged User is not nil refreshes the User with data stored on the server
 *  Returns the refreshed logged User or nil
 */

- (void)refreshLoggedUser:(void (^)(MKUser *user, NSError *error))block;

/** @name API Endpoint */

/**
 The API endpoint
 @return Returns the API endpoint absolute URL string
 @exception NSInternalInconsistencyException Raises exception if API endpoint is not set
 */
- (NSString *)APIEndpoint;

/**
 The API secret
 @return Returns the API secret string
 @exception NSInternalInconsistencyException Raises exception if API secret is not set
 */
- (NSString *)APISecret;

/**
 The network service to permorme authenticated requests
 @return Returns the 'MIANetwork' instance in order to perform authenticated requests
 */
- (MIANetwork *)network;

/**
 Set the API secret
 @param secret The API secret
 */
- (void)setAPISecret:(NSString *)secret;

/**
 Set the API endpoint
 @param absoluteString The absolute URL string for the API endpoint
 */
//+ (void)setAPIEndpoint:(NSString *)absoluteString;
- (void)setAPIEndpointType:(MKEndPointType)type __attribute__((deprecated));

/**
 Check if version is the latest available.
 @param version The version to compare. You can use the dotted format or pure number format. Hex format is not supported.
 @param key The key used to read the version value from "appconfiguration" collection.
 @param completion Completion will be called after reading the latest available version from server. Completion will provide a BOOL that tells if the version is the latest and a error if any. If an error occurs isLatestVersion is always YES.
 */
- (void)isLatestAvailableVersion:(NSString * _Nonnull)version remoteKey:(NSString * _Nonnull)key completion:(void(^_Nonnull)(BOOL isLatestVersion,NSError*_Nullable error))completion;

/**
 Check if build version of `bundle` is the latest available.
 @param bundle The bundle used for fetching infos and compare the app version with the remote value.
 @param completion Completion will be called after reading the latest available version from server. Completion will provide a BOOL that tells if the version is the latest and a error if any. If an error occurs isLatestVersion is always YES.
 @discussion From the bundle, the method will take the bundle identifier and the bundle version. The latest available version will be read from remote, from the "appconfiguration" collection, with value for key "ios:BUNDLEID:latestAppVersion".
 */
- (void)isLatestAvailableVersion:(NSBundle * _Nonnull)bundle completion:(void(^_Nonnull)(BOOL isLatestVersion,NSError*_Nullable error))completion;

/** @name Serial Request Queue */

/**
 Dispatch queue for API requests
 @return The shared serial dispatch queue for API requests
 */
- (dispatch_queue_t)queue;

/** @name Debug */

/**
 Enables the request log.

 This is useful for tracking down performance issues during development
 @param flag `YES` to enable logging, `NO` to disable
 */
- (void)setRequestLogEnabled:(BOOL)flag __attribute__((deprecated));
+ (void)setLogLevel:(MIALogLevel)logLevel;

/**
 Returns the request log status
 @return `YES` if the request log is enabled, `NO` otherwise
 */
- (BOOL)requestLogEnabled __attribute__((deprecated));
+ (MIALogLevel)currentLogLevel;

/**
 Rester the device token on the Baas for remote push notification
 @param devToken get this from AppDelegate application:didRegisterForRemoteNotificationsWithDeviceToken:
 @param user the associated user. It's optional insert nil if you don't know the user that own the device
 */
- (void)didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)devToken
                                                 forUser:(MKUser *)user __attribute__((deprecated));

/**
 Rester the device token on the Baas for remote push notification
 @param devToken get this from AppDelegate application:didRegisterForRemoteNotificationsWithDeviceToken:
 @param user the associated user. It's optional insert nil if you don't know the user that own the device
 @param block the callback block
 */
- (void)didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)devToken
                                                 forUser:(MKUser *)user
                                                   block:(void (^)(MKCollection *device, NSError *error))block;

/**
 Register the App for RemoteNotification
 Call this method in your AppDelegate application:didFinishLaunchingWithOptions:
 @deprecated Register to your notification manually setting the @e UIUserNotificationSettings
 that are better for your application.
 */
+ (void)refisterForRemoteNotification __attribute__((deprecated));

@end

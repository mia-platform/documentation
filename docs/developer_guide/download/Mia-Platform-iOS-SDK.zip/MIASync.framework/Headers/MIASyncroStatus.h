//
//  MIASyncroStatus.h
//  mkApp
//
//  Created by Francesco Burelli on 12/04/2017.
//  Copyright © 2017 MakeItApp.eu. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 MIASyncroStatus represent the status of MIASyncro.
 */
@interface MIASyncroStatus : NSObject <NSCopying>

/**
 YES if MIASyncro is synching (pulling or pushing).
 */
@property (nonatomic, readonly) BOOL synching;
/**
 The date of the last sync completed with success.
 */
@property (nonatomic, readonly) NSDate * _Nullable lastSync;

/**
 The last synched entity.
 */
@property (nonatomic, readonly) Class _Nullable lastSynchedEntity;
/**
 The entity that is synching now.
 */
@property (nonatomic, readonly) Class _Nullable synchingEntity;

/**
 The entity that is pulling now from the BaaS.
 */
@property (nonatomic, readonly) Class _Nullable pullingEntity;
/**
 The last pulled entity from BaaS.
 */
@property (nonatomic, readonly) Class _Nullable lastPulledEntity;
/**
 The entity that is pushing now to the BaaS.
 */
@property (nonatomic, readonly) Class _Nullable pushingEntity;
/**
 The last pushed entity to BaaS.
 */
@property (nonatomic, readonly) Class _Nullable lastPushedEntity;
/**
 The last error occured during the sync.
 */
@property (nonatomic, readonly) NSError * _Nullable error;

/**
 The current progress of sync if MIASyncro is synching.
 */
@property (nonatomic, readonly) NSProgress * _Nullable progress;

@end

//
//  MIASync.h
//  MIASync
//
//  Created by Francesco Burelli on 10/04/2017.
//  Copyright © 2017 MakeItApp.eu. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MIASync.
FOUNDATION_EXPORT double MIASyncVersionNumber;

//! Project version string for MIASync.
FOUNDATION_EXPORT const unsigned char MIASyncVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MIASync/PublicHeader.h>


#import "MIASyncro.h"

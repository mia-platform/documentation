//
//  CRUD.h
//  CRUD
//
//  Created by Simone Montalto on 06/08/18.
//  Copyright © 2018 Mia-Platform. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CRUD.
FOUNDATION_EXPORT double CRUDVersionNumber;

//! Project version string for CRUD.
FOUNDATION_EXPORT const unsigned char CRUDVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CRUD/PublicHeader.h>

#import "NSManagedObject+Utilities.h"



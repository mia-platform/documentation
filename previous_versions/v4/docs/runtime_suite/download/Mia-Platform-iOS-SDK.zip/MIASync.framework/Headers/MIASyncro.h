//
//  MIASyncro.h
//  mkApp
//
//  Created by Francesco Burelli on 10/04/2017.
//  Copyright © 2017 MakeItApp.eu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "MIASyncroStatus.h"
#import "NSManagedObject+MIASyncro.h"

/**
 The id key of collection.
 */
extern NSString * _Nonnull const kMIACollectionKeyId;
/**
 The createdAt key of collection.
 */
extern NSString * _Nonnull const kMIACollectionKeyCreatedAt;
/**
 The updatedAt key of collection.
 */
extern NSString * _Nonnull const kMIACollectionKeyUpdatedAt;
/**
 The sync key of collection.
 */
extern NSString * _Nonnull const kMIACollectionKeySync;
/**
 The trash key of collection.
 */
extern NSString * _Nonnull const kMIACollectionKeyTrash;

/**
 The name of the notification raised by MIASyncro.
 */
extern NSString * _Nonnull const kMIASyncroNotification;
/**
 The key of userInfo of the notification raised by MIASyncro to get the MIASyncroStatus.
 */
extern NSString * _Nonnull const kMIASyncroNotificationKeyStatus;

/**
 MIASyncro is a class for @b syncing  @b data from BaaS into the local database and viceversa. The local database is represented and referenced by a NSManagedObjectContext.
 The sync behaviour is inspired by git: there are a @b pull action first and then a @b push action. Changes from BaaS have greater priority than local changes so, if a conflict is present, changes from BaaS will replace local changes.
 In particular values from BaaS that have @b updatedAt greater than @b updatedAt of local objects, these local objects will be updated (replaced) or deleted, depends on the status.
 */
@interface MIASyncro : NSObject

/**
 The managed object context used to sync data from and to the BaaS.
 */
@property (nonatomic, readonly) NSManagedObjectContext * _Nonnull managedObjectContext;
/**
 Sync uses pagination, syncPageSize is the maximum number of element to get from BaaS for each page. The default value is 100.
 */
@property (nonatomic, assign) NSUInteger syncPageSize;
/**
 Store (or not) draft in the local database. The default is NO.
 */
@property (nonatomic, assign) BOOL keepDrafts;
/**
 The current status of MIASyncro.
 You can observe the change of this status via NSNotificationCenter observing the notification @b kMIASyncroNotification.
 */
@property (nonatomic, readonly) MIASyncroStatus * _Nonnull status;

/**
 Init MIASyncro with a custom NSManagedObjectContext.
 @param context the context to use for reading and writing.
 @return an instance of MIASyncro or nil if an error occurs.
 */
- (instancetype _Nullable)initWithManagedObjectContext:(NSManagedObjectContext *_Nonnull)context;

/**
 Init MIASyncro with a model. MIASyncro will create a default managedObjectContext using this model.
 @param model the core data model to use to create the core default core data stack.
 @return an instance of MIASyncro or nil if an error occurs.
 */
- (instancetype _Nullable)initWithManagedObjectModel:(NSManagedObjectModel *_Nonnull)model;

/**
 Synchronize all the entities of requested types. The status of sync is notified by the NotificationCenter. The operation is asyncronous. You can call sync: multiple times, but if it is syncing this method do nothing.
 @param types array of types (classes) to synchronize. Types that are not subclass of NSManagedObject will be skipped. Every type must have the followings properties: id : String, createdAt : Date, updatedAt : Date, sync : NSInteger, trash: NSIntefer. The suggestion is to create a root model Class that implementets the previous properties.
 */
- (void)sync:(NSArray<Class> * _Nonnull)types;

/**
 Entities will be marked as "toPush", but will not be pushed to BaaS, you have to call sync: to push data to the BaaS.
 @param entities the entities to push
 */
- (void)toPush:(NSArray<NSManagedObject*>*_Nonnull)entities;
/**
 Entities will be marked as "trash", but will not be pushed to BaaS, you have to call sync: to push data to the BaaS.
 Trashing an entity means that the entity will not be deleted from BaaS, it will just change its own status to trash.
 A trashed entity will be deleted from local database at the next sync:
 @param entities the entities to trash
 */
- (void)trash:(NSArray<NSManagedObject*>*_Nonnull)entities;
/**
 Entities will be marked as "toDelete", but will not be pushed to BaaS, you have to call sync: to push data to the BaaS.
 Deleting an entity means that the entity will be deleted from BaaS and you will not able to recover it.
 A deleted entity will be deleted from local database at the next sync:
 @param entities the entities to delete
 */
- (void)delete:(NSArray<NSManagedObject*>*_Nonnull)entities;

@end

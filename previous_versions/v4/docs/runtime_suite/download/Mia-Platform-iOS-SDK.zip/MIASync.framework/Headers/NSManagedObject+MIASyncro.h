//
//  NSManagedObject+MIASyncro.h
//  mkApp
//
//  Created by Francesco Burelli on 11/04/2017.
//  Copyright © 2017 MakeItApp.eu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface NSManagedObject (MIASyncro)

/**
 By default the collectionName is the name of entity class lowercased with an 's' appended.
 Subclasses should override this method if the default behaviour is not correct.
 @return the collection name associated to the entity of current class.
 */
+ (NSString * _Nonnull)collectionName;

/**
 By default the syncEndPoint is the composition of 'sync/' and the collectionName.
 Subclasses should override this method if the default behaviour is not correct.
 @return the collection endpoint associated to the entity of current class.
 */
+ (NSString * _Nonnull)syncEndPoint;

/**
 If there is the necessity, it is possible to map the name of the attributes of the collection
 with another name. By default, it is returned an empty dictionary.
 Subclasses should override this method if there are some name attributes to map.
 @return the collection endpoint associated to the entity of current class.
 */
+ (NSDictionary<NSString*,NSString*> * _Nonnull)mapNameAttributes;

@end

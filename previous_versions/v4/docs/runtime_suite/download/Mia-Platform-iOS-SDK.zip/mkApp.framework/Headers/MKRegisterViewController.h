//
//  RegisterViewController.h
//  mkApp
//
//  Created by Francesco Soncini Sessa on 20/07/14.
//  Copyright © 2017 MIA s.r.l.. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <mkApp/MKLoginDelegate.h>

@interface MKRegisterViewController : UIViewController

@property (nonatomic, weak) id<MKLoginDelegate> delegate;

- (instancetype)initWithDelegate:(id<MKLoginDelegate>)delegate;

@end

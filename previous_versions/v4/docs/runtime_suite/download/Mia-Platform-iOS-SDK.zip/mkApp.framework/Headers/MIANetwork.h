//
//  MIANetwork.h
//  mkApp
//
//  Created by Simone Montalto on 02/02/18.
//  Copyright © 2018 MakeItApp.eu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MKCollection.h"

@class MIANetwork;

@interface MIANetwork : NSObject

/**
 Initialize MIANetwork
 @param urlSessionConfiguration The URLSessionCOnfiguration with authentication informations in the header
 @param baseUrl The base url
 @return The initialized object
 */
- (id _Nonnull)initWithUrlSessionConfiguration:(NSURLSessionConfiguration * _Nonnull)urlSessionConfiguration baseUrl:(NSString* _Nonnull)baseUrl;

/**
 Create 'NSURLSessionUploadTask' in order to perform authenticated 'PATCH' request
 
 Create an authenticated 'NSURLSessionUploadTask' with body
 @param path The relative path
 @param data The data to upload
 @param contentType The content type of the file to upload
 @param error The error object to be set on error
 @param completionHandler Callback when operation is finished
 @return 'NSURLSessionUploadTask' on success, nil on error
 */
- (NSURLSessionUploadTask * _Nullable)patchTaskWithRelativePath:(NSString* _Nonnull)path
                                                          data:(NSData* _Nonnull)data
                                                   contentType:(NSString* _Nonnull)contentType
                                                         error:(NSError * _Nullable * _Nullable)error
                                             completionHandler:(void(^_Nullable)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHanadler;

/**
 Create 'NSURLSessionUploadTask' in order to perform authenticated 'PATCH' request. The content type of the body is setted to JSON
 
 Create an authenticated 'NSURLSessionUploadTask' with body
 @param path The relative path
 @param data The data to upload
 @param error The error object to be set on error
 @param completionHandler Callback when operation is finished
 @return 'NSURLSessionUploadTask' on success, nil on error
 */
- (NSURLSessionUploadTask * _Nullable)patchTaskWithRelativePath:(NSString* _Nonnull)path
                                                           data:(NSData* _Nonnull)data
                                                          error:(NSError * _Nullable * _Nullable)error
                                              completionHandler:(void(^_Nullable)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHanadler;

/**
 Create 'NSURLSessionUploadTask' in order to perform authenticated 'POST' request
 
 Create an authenticated 'NSURLSessionUploadTask' with body
 @param path The relative path
 @param body A dictionary containing the data to insert in the body which will be converted in a JSON file
 @param error The error object to be set on error
 @param completionHandler Callback when operation is finished
 @return 'NSURLSessionUploadTask' on success, nil on error
 */
- (NSURLSessionUploadTask * _Nullable)postTaskWithRelativePath:(NSString* _Nonnull)path
                                                          body:(NSDictionary<NSString *,NSString *>* _Nonnull)body
                                                         error:(NSError * _Nullable * _Nullable)error
                                             completionHandler:(void(^_Nullable)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHanadler;

/**
 Create 'NSURLSessionUploadTask' in order to perform authenticated 'POST' request
 
 Create an authenticated 'NSURLSessionUploadTask' with body
 @param path The relative path
 @param data The data to upload
 @param contentType The content type of the file to upload. In 'nil', JSON content type is setted
 @param error The error object to be set on error
 @param completionHandler Callback when operation is finished
 @return 'NSURLSessionUploadTask' on success, nil on error
 */
- (NSURLSessionUploadTask * _Nullable)postTaskWithRelativePath:(NSString* _Nonnull)path
                                                          data:(NSData* _Nonnull)data
                                                   contentType:(NSString* _Nonnull)contentType
                                                         error:(NSError * _Nullable * _Nullable)error
                                             completionHandler:(void(^_Nullable)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHanadler;

/**
 Create 'NSURLSessionUploadTask' in order to perform authenticated 'POST' request. The content type of the body is setted to JSON
 
 Create an authenticated 'NSURLSessionUploadTask' with body
 @param path The relative path
 @param data The data to upload
 @param contentType The content type of the file to upload. In 'nil', JSON content type is setted
 @param error The error object to be set on error
 @param completionHandler Callback when operation is finished
 @return 'NSURLSessionUploadTask' on success, nil on error
 */
- (NSURLSessionUploadTask * _Nullable)postTaskWithRelativePath:(NSString* _Nonnull)path
                                                          data:(NSData* _Nonnull)data
                                                         error:(NSError * _Nullable * _Nullable)error
                                             completionHandler:(void(^_Nullable)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHanadler;

/**
 Create 'NSURLSessionDataTask' in order to perform authenticated 'GET' request. The callback returns a NSData
 
 Create an authenticated 'NSURLSessionDataTask' with query parameters
 @param path The relative path
 @param parameters A dictionary containing the parameters to perform the query
 @param error The error object to be set on error
 @param completionHandler Callback when operation is finished
 @return 'NSURLSessionDataTask' on success, nil on error
 */
- (NSURLSessionDataTask * _Nullable)getDataTaskWithRelativePath:(NSString* _Nonnull)path
                                            queryParameters:(NSDictionary<NSString *,NSString *>* _Nullable)parameters
                                                      error:(NSError * _Nullable * _Nullable)error
                                          completionHandler:(void(^_Nonnull)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHanadler;

/**
 Create 'NSURLSessionDataTask' in order to perform authenticated 'GET' request. The callback returns an array of MKCollection
 
 Create an authenticated 'NSURLSessionDataTask' with query parameters
 @param path The relative path. It is used as the name of the collection
 @param parameters A dictionary containing the parameters to perform the query
 @param error The error object to be set on error
 @param completionHandler Callback when operation is finished
 @return 'NSURLSessionDataTask' on success, nil on error
 */
- (NSURLSessionDataTask * _Nullable)getCollectionTaskWithRelativePath:(NSString* _Nonnull)path
                                            queryParameters:(NSDictionary<NSString *,NSString *>* _Nullable)parameters
                                                      error:(NSError * _Nullable * _Nullable)error
                                          completionHandler:(void(^_Nonnull)(NSArray<MKCollection*> * _Nullable results, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHanadler;

/**
 Create 'NSURLSessionDataTask' in order to perform authenticated 'GET' request. The callback returns a NSDictionary
 
 Create an authenticated 'NSURLSessionDataTask' with query parameters
 @param path The relative path
 @param parameters A dictionary containing the parameters to perform the query
 @param error The error object to be set on error
 @param completionHandler Callback when operation is finished
 @return 'NSURLSessionDataTask' on success, nil on error
 */
- (NSURLSessionDataTask * _Nullable)getDictionaryTaskWithRelativePath:(NSString* _Nonnull)path
                                                       queryParameters:(NSDictionary<NSString *,NSString *>* _Nullable)parameters
                                                                 error:(NSError * _Nullable * _Nullable)error
                                                     completionHandler:(void(^_Nonnull)(NSDictionary* _Nullable results, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHanadler;

/**
 Create 'NSURLSessionDataTask' in order to perform authenticated 'DELETE' request
 
 Create an authenticated 'NSURLSessionDataTask' with body
 @param path The relative path
 @param body A dictionary containing the data to insert in the body
 @param error The error object to be set on error
 @param completionHandler Callback when operation is finished
 @return 'NSURLSessionDataTask' on success, nil on error
 */
- (NSURLSessionUploadTask * _Nullable)deleteTaskWithRelativePath:(NSString* _Nonnull)path
                                                          body:(NSDictionary<NSString *,NSString *>* _Nonnull)body
                                                         error:(NSError * _Nullable * _Nullable)error
                                             completionHandler:(void(^_Nullable)(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error))completionHanadler;

@end

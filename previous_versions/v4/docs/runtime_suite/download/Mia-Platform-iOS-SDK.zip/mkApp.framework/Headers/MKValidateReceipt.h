//
//  MKValidateReceipt.h
//  mkApp
//
//  Created by Mia Srl on 9/16/13.
//  Copyright © 2017 MIA s.r.l.. All rights reserved.
//

#import <Foundation/Foundation.h>

@class SKPaymentTransaction, MKCollection;

NS_ASSUME_NONNULL_BEGIN

typedef void (^MIAValidationResponseBlock)(MKCollection *_Nullable receipt, NSError *_Nullable error);

@interface MKValidateReceipt : NSObject

+ (void)validateTransactionReceipt:(SKPaymentTransaction *)transaction
                         withBlock:(void (^)(MKCollection *_Nullable receipt, NSError *_Nullable error))block
    __attribute__((deprecated));

+ (void)validateReceiptWithCompletionBlock:(MIAValidationResponseBlock)block;

@end

NS_ASSUME_NONNULL_END
